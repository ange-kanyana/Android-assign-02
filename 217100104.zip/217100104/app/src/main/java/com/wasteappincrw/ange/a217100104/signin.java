package com.wasteappincrw.ange.a217100104;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class signin extends AppCompatActivity {

    Button register,login;
    EditText username,password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);

        register = findViewById(R.id.register);
        login = findViewById(R.id.loginBtn);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(signin.this, MainActivity.class);
                startActivity(intent);
            }
        });

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String Username = "ange";
                String Password = "123456";

                String enteredUsername = username.getText().toString();
                String enteredPassword = password.getText().toString();

                if ((enteredUsername.equals(Username)) && (enteredPassword.equals(Password))){

                    Toast.makeText(signin.this,"Success",Toast.LENGTH_LONG).show();
                }else{

                    Toast.makeText(signin.this,"Invalid Username or Password",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
